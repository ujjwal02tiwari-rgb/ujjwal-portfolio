# premier-portfolio

That's "First portfolio" in French ✨

## Screenshot 📸

![Israel Mitolu portfolio screenshot](./assets/img/seo-img.png)

## Live Site 🚀

[Preview the website here](https://israelmitolu.netlify.app).

## Tools 🔨

Built using HTML, CSS(SCSS), Javascript and GSAP
